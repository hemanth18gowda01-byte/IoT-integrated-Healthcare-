# 🫀 VitalSync — AI-Powered Health Monitoring Platform

> A full-stack IoT health monitoring system with ML-powered diagnostics, emergency alerts, and interconnected patient-hospital-pharmacy interfaces.

---

## 📐 Architecture Overview

```
vitalsync/
├── backend/          # FastAPI + ML (Python)
├── frontend/         # PWA (HTML/CSS/JS)
├── iot/              # Sensor simulator + MQTT broker code
└── docs/             # API docs, hardware guide
```

### Tech Stack
| Layer | Technology |
|-------|-----------|
| Backend API | FastAPI (Python 3.11+) |
| ML Models | scikit-learn + Anthropic Claude API |
| Database | MySQL 8.0 (SQLAlchemy ORM) |
| Frontend | Vanilla JS PWA (installable on mobile) |
| IoT Broker | Mosquitto MQTT |
| Auth | JWT (HS256) |
| Encryption | Fernet (AES-128-CBC) for sensitive DB fields |
| Alerts | WebSockets (FastAPI) |

---

## 🚀 Quick Start

### Prerequisites
- Python 3.11+
- MySQL 8.0+
- Node.js 18+ (for MQTT broker tooling)
- An Anthropic API key (for LLM daily check-in)

### 1. Clone & Setup Backend

```bash
git clone https://github.com/YOUR_USERNAME/vitalsync.git
cd vitalsync/backend

python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your MySQL credentials and Anthropic API key
```

### 3. Setup MySQL Database

```sql
CREATE DATABASE vitalsync CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'vitalsync'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON vitalsync.* TO 'vitalsync'@'localhost';
FLUSH PRIVILEGES;
```

```bash
cd backend
alembic upgrade head          # Run migrations
python seed.py                # Seed default hospital, pharmacy, blood bank
```

### 4. Train ML Models

```bash
cd backend
python -m app.ml.train        # Trains vitals classifier + saves models
```

### 5. Run Backend

```bash
uvicorn app.main:app --reload --port 8000
# API docs: http://localhost:8000/docs
```

### 6. Run Frontend

```bash
cd frontend
# Just open index.html in browser, OR use a local server:
python -m http.server 3000
# Visit: http://localhost:3000
```

### 7. Run IoT Simulator

```bash
cd iot
pip install -r requirements.txt
python simulator.py --user-id 1 --interval 5   # Sends vitals every 5s
```

### 8. Run MQTT Broker (Real Devices)

```bash
# Install Mosquitto
sudo apt install mosquitto mosquitto-clients   # Ubuntu
brew install mosquitto                          # macOS

# Start broker
mosquitto -c mosquitto.conf

# Bridge to FastAPI (handled automatically by backend MQTT client)
```

---

## 🌐 Deployment (Production)

### Backend on Railway / Render

```bash
# Set environment variables in dashboard:
DATABASE_URL=mysql+pymysql://user:pass@host:3306/vitalsync
ANTHROPIC_API_KEY=sk-ant-...
SECRET_KEY=your-jwt-secret-256bit
ENCRYPTION_KEY=your-fernet-key

# Deploy command:
uvicorn app.main:app --host 0.0.0.0 --port $PORT
```

### Frontend on Vercel / Netlify

```bash
# Just drag the /frontend folder to Netlify
# Or connect GitHub repo and set publish dir to /frontend
```

### Docker (Full Stack)

```bash
docker-compose up --build
```

---

## 📡 Connecting Real IoT Devices

### Supported Hardware
| Sensor | Module | Protocol |
|--------|--------|----------|
| Heart Rate + SpO2 | MAX30102 | I2C |
| ECG | AD8232 | Analog/SPI |
| Temperature | MLX90614 | I2C |
| Motion/Fall | MPU6050 | I2C |
| Microcontroller | ESP32 | WiFi/MQTT |

### ESP32 Setup
See `iot/esp32_firmware/` for MicroPython code.

```
ESP32 → reads sensors → publishes to MQTT topic:
  vitalsync/user/{user_id}/vitals
```

### Wiring Diagram
```
ESP32 GPIO:
  GPIO 21 (SDA) → MAX30102 SDA, MLX90614 SDA, MPU6050 SDA
  GPIO 22 (SCL) → MAX30102 SCL, MLX90614 SCL, MPU6050 SCL
  GPIO 34 (ADC) → AD8232 OUTPUT
  3.3V → All sensors VCC
  GND  → All sensors GND
```

---

## 🔒 Security Notes
- All sensitive fields (medical records, prescriptions) are Fernet-encrypted in DB
- JWT tokens expire in 24h (configurable)
- HTTPS enforced in production
- Emergency alerts use WebSocket with token auth

---

## 📊 ML Model Details
- **Vitals Classifier**: Random Forest trained on synthetic + public health datasets
- **Anomaly Detector**: Isolation Forest for unusual vital sign patterns  
- **Daily Check-in**: Claude API (claude-sonnet-4-20250514) for natural language health Q&A
- **Disease Prediction**: Rule-based + Gradient Boosting for 15 common conditions

---

## 🧪 Testing

```bash
cd backend
pytest tests/ -v
```

---

## 📄 License
MIT License — See LICENSE file.
