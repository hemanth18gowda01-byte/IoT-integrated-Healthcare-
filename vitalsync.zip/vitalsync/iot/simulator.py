#!/usr/bin/env python3
"""
VitalSync IoT Sensor Simulator
Simulates ESP32 + MAX30102 + MLX90614 + MPU6050 + AD8232
Sends realistic vitals via MQTT or directly to REST API.

Usage:
  python simulator.py --user-id 1 --interval 5 --mode mqtt
  python simulator.py --user-id 1 --interval 10 --mode api --api-url http://localhost:8000
  python simulator.py --user-id 1 --scenario emergency  # triggers emergency vitals
"""
import argparse
import json
import math
import random
import time
import requests
from datetime import datetime


# ── Vital Sign Simulator ────────────────────────────────────────────────────────

class VitalSimulator:
    """Simulates continuous, realistic vital sign data with circadian variation."""

    def __init__(self, scenario: str = "healthy"):
        self.scenario = scenario
        self.baseline = self._get_baseline()
        self.t = 0  # time ticks

    def _get_baseline(self) -> dict:
        scenarios = {
            "healthy": dict(hr=72, spo2=98.5, temp=36.8, sys=118, dia=78, ecg=0.5),
            "athlete": dict(hr=58, spo2=99, temp=36.6, sys=110, dia=70, ecg=0.45),
            "hypertensive": dict(hr=82, spo2=97, temp=36.9, sys=148, dia=95, ecg=0.55),
            "fever": dict(hr=95, spo2=96, temp=38.8, sys=130, dia=85, ecg=0.6),
            "bradycardia": dict(hr=45, spo2=95, temp=36.5, sys=100, dia=65, ecg=0.7),
            "tachycardia": dict(hr=130, spo2=94, temp=37.2, sys=140, dia=90, ecg=0.8),
            "hypoxia": dict(hr=100, spo2=88, temp=37.0, sys=125, dia=82, ecg=0.65),
            "emergency": dict(hr=170, spo2=82, temp=40.2, sys=185, dia=115, ecg=1.8),
        }
        return scenarios.get(self.scenario, scenarios["healthy"])

    def _add_noise(self, value: float, noise: float = 0.02) -> float:
        """Add realistic sensor noise."""
        return value * (1 + random.gauss(0, noise))

    def _circadian_variation(self, hour: int) -> dict:
        """Simulate circadian rhythm effects (heart rate/BP vary by time of day)."""
        # Morning surge, afternoon dip, evening recovery
        hr_offset = 5 * math.sin((hour - 6) * math.pi / 12)
        bp_offset = 8 * math.sin((hour - 6) * math.pi / 12)
        return {"hr_offset": hr_offset, "bp_offset": bp_offset}

    def generate_reading(self) -> dict:
        self.t += 1
        hour = datetime.now().hour
        circ = self._circadian_variation(hour)

        b = self.baseline
        # Slight random walk to simulate real sensor drift
        self.baseline["hr"] += random.gauss(0, 0.3)
        self.baseline["hr"] = max(30, min(200, self.baseline["hr"]))

        # Simulate motion/fall
        motion_x = self._add_noise(0.1, 0.5)
        motion_y = self._add_noise(0.05, 0.5)
        motion_z = self._add_noise(9.81, 0.02)  # gravity
        fall_detected = abs(motion_z - 9.81) > 4.0  # sudden z-axis change

        # ECG waveform simulation (simplified)
        ecg_base = b["ecg"]
        ecg_t = self.t % 60  # 60 samples per beat cycle
        if 25 <= ecg_t <= 27:
            ecg_value = ecg_base + 1.5  # R wave peak
        elif 20 <= ecg_t <= 24:
            ecg_value = ecg_base - 0.2  # Q wave
        elif 28 <= ecg_t <= 32:
            ecg_value = ecg_base - 0.1  # S wave
        else:
            ecg_value = ecg_base + random.gauss(0, 0.03)

        reading = {
            "heart_rate": round(max(20, self._add_noise(b["hr"] + circ["hr_offset"], 0.015)), 1),
            "spo2": round(min(100, max(70, self._add_noise(b["spo2"], 0.003))), 1),
            "temperature": round(self._add_noise(b["temp"], 0.004), 2),
            "systolic_bp": round(max(50, self._add_noise(b["sys"] + circ["bp_offset"], 0.02)), 1),
            "diastolic_bp": round(max(30, self._add_noise(b["dia"], 0.02)), 1),
            "ecg_value": round(ecg_value, 3),
            "motion_x": round(motion_x, 3),
            "motion_y": round(motion_y, 3),
            "motion_z": round(motion_z, 3),
            "fall_detected": fall_detected,
            "timestamp": datetime.utcnow().isoformat(),
            "device_id": "ESP32-DEMO-001",
        }
        return reading

    def generate_emergency_sequence(self, n: int = 5) -> list:
        """Generate a sequence of escalating emergency vitals."""
        emergency = VitalSimulator("emergency")
        return [emergency.generate_reading() for _ in range(n)]


# ── MQTT Publisher ─────────────────────────────────────────────────────────────

def publish_via_mqtt(reading: dict, user_id: int, broker: str = "localhost", port: int = 1883):
    try:
        import paho.mqtt.client as mqtt
        client = mqtt.Client()
        client.connect(broker, port, keepalive=60)
        topic = f"vitalsync/user/{user_id}/vitals"
        payload = json.dumps(reading)
        result = client.publish(topic, payload, qos=1)
        client.disconnect()
        print(f"📡 MQTT → {topic}: HR={reading['heart_rate']} SpO2={reading['spo2']} Temp={reading['temperature']}°C")
        return True
    except Exception as e:
        print(f"❌ MQTT error: {e}")
        return False


# ── REST API Publisher ─────────────────────────────────────────────────────────

def publish_via_api(reading: dict, api_url: str, token: str):
    try:
        resp = requests.post(
            f"{api_url}/api/patient/vitals",
            json={k: v for k, v in reading.items() if k not in ("timestamp", "device_id")},
            headers={"Authorization": f"Bearer {token}"},
            timeout=10
        )
        result = resp.json()
        status = result.get("status", "unknown")
        print(f"🌐 API → Status: {status.upper()} | HR={reading['heart_rate']} SpO2={reading['spo2']} Temp={reading['temperature']}°C")
        if result.get("emergency"):
            print(f"🚨 EMERGENCY DETECTED: {result.get('analysis', {}).get('emergency_flags')}")
        return result
    except Exception as e:
        print(f"❌ API error: {e}")
        return None


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="VitalSync IoT Simulator")
    parser.add_argument("--user-id", type=int, default=1)
    parser.add_argument("--interval", type=float, default=5, help="Seconds between readings")
    parser.add_argument("--mode", choices=["mqtt", "api", "print"], default="print")
    parser.add_argument("--scenario", default="healthy",
                        choices=["healthy", "athlete", "hypertensive", "fever", "bradycardia", "tachycardia", "hypoxia", "emergency"])
    parser.add_argument("--api-url", default="http://localhost:8000")
    parser.add_argument("--token", default="", help="JWT token for API mode")
    parser.add_argument("--mqtt-host", default="localhost")
    parser.add_argument("--mqtt-port", type=int, default=1883)
    parser.add_argument("--count", type=int, default=0, help="Number of readings (0 = infinite)")
    args = parser.parse_args()

    simulator = VitalSimulator(scenario=args.scenario)

    print(f"🚀 VitalSync IoT Simulator")
    print(f"   Scenario: {args.scenario.upper()}")
    print(f"   Mode:     {args.mode.upper()}")
    print(f"   Interval: {args.interval}s")
    print(f"   User ID:  {args.user_id}")
    print("─" * 50)

    i = 0
    while True:
        reading = simulator.generate_reading()

        if args.mode == "mqtt":
            publish_via_mqtt(reading, args.user_id, args.mqtt_host, args.mqtt_port)
        elif args.mode == "api":
            if not args.token:
                print("⚠️  API mode requires --token. Get it by logging in first.")
                break
            publish_via_api(reading, args.api_url, args.token)
        else:
            # Print mode — just display
            status = "🟢" if reading["heart_rate"] < 100 and reading["spo2"] > 95 else "🔴"
            print(f"{status} {reading['timestamp']} | HR:{reading['heart_rate']} | SpO2:{reading['spo2']}% | Temp:{reading['temperature']}°C | BP:{reading['systolic_bp']}/{reading['diastolic_bp']} | Fall:{reading['fall_detected']}")

        i += 1
        if args.count and i >= args.count:
            print(f"✅ Completed {i} readings")
            break

        time.sleep(args.interval)


if __name__ == "__main__":
    main()
