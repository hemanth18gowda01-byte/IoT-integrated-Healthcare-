"""
VitalSync ESP32 Firmware (MicroPython)
Reads from: MAX30102 (HR/SpO2), MLX90614 (temp), MPU6050 (motion/fall), AD8232 (ECG)
Publishes to: MQTT broker → VitalSync backend

Flashing:
  1. Install MicroPython on ESP32: https://micropython.org/download/esp32/
  2. Install required libraries via upip or Thonny:
     - micropython-umqtt.robust
     - micropython-max30102 (or use I2C directly)
  3. Upload this file as main.py to ESP32

Wiring:
  MAX30102:  SDA=GPIO21, SCL=GPIO22, INT=GPIO4, 3.3V, GND
  MLX90614:  SDA=GPIO21, SCL=GPIO22, 3.3V, GND
  MPU6050:   SDA=GPIO21, SCL=GPIO22, 3.3V, GND
  AD8232:    OUTPUT=GPIO34(ADC), LO-=GPIO33, LO+=GPIO32, 3.3V, GND

NOTE: This is firmware code — run on real hardware, not in Python environment.
"""
import machine
import network
import time
import json
import math
from machine import Pin, I2C, ADC

# ── Configuration ─────────────────────────────────────────────────────────────
WIFI_SSID = "YOUR_WIFI_SSID"
WIFI_PASS = "YOUR_WIFI_PASSWORD"
MQTT_BROKER = "192.168.1.100"   # Your VitalSync backend IP
MQTT_PORT = 1883
MQTT_USER = "vitalsync"
MQTT_PASS = "mqtt_password"
DEVICE_ID = "ESP32-001"
USER_ID = "1"                    # VitalSync user ID
PUBLISH_INTERVAL = 5             # Seconds between readings

MQTT_TOPIC = f"vitalsync/user/{DEVICE_ID}/vitals"

# ── I2C Setup ─────────────────────────────────────────────────────────────────
i2c = I2C(0, sda=Pin(21), scl=Pin(22), freq=400000)

# ── AD8232 ECG ────────────────────────────────────────────────────────────────
ecg_adc = ADC(Pin(34))
ecg_adc.atten(ADC.ATTN_11DB)    # 0-3.6V range
lo_minus = Pin(33, Pin.IN)
lo_plus = Pin(32, Pin.IN)


# ── MAX30102 HR/SpO2 (simplified I2C driver) ──────────────────────────────────
MAX30102_ADDR = 0x57
MAX30102_INT_STATUS = 0x00
MAX30102_FIFO_DATA = 0x07
MAX30102_MODE = 0x09
MAX30102_SPO2_CONFIG = 0x0A
MAX30102_LED1_PA = 0x0C
MAX30102_LED2_PA = 0x0D

def max30102_init():
    i2c.writeto_mem(MAX30102_ADDR, MAX30102_MODE, bytes([0x03]))  # SpO2 mode
    i2c.writeto_mem(MAX30102_ADDR, MAX30102_SPO2_CONFIG, bytes([0x27]))  # 100Hz, 411us
    i2c.writeto_mem(MAX30102_ADDR, MAX30102_LED1_PA, bytes([0x24]))  # Red LED ~7mA
    i2c.writeto_mem(MAX30102_ADDR, MAX30102_LED2_PA, bytes([0x24]))  # IR LED ~7mA

def max30102_read():
    """Read HR and SpO2 from MAX30102. Returns (heart_rate, spo2)."""
    try:
        raw = i2c.readfrom_mem(MAX30102_ADDR, MAX30102_FIFO_DATA, 6)
        red = (raw[0] << 16 | raw[1] << 8 | raw[2]) & 0x3FFFF
        ir  = (raw[3] << 16 | raw[4] << 8 | raw[5]) & 0x3FFFF

        # Simplified SpO2 calculation (R ratio method)
        if ir > 50000 and red > 50000:
            R = (red / ir)
            spo2 = 110 - 25 * R
            spo2 = max(70, min(100, spo2))
        else:
            spo2 = 0  # No finger detected

        # HR: count peaks (simplified — real implementation uses peak detection)
        heart_rate = 72  # placeholder — use proper peak detection algorithm
        return round(heart_rate, 1), round(spo2, 1)
    except Exception:
        return 0, 0


# ── MLX90614 Temperature ──────────────────────────────────────────────────────
MLX90614_ADDR = 0x5A
MLX90614_TOBJ1 = 0x07

def mlx90614_read_temp():
    """Read object (body) temperature from MLX90614. Returns Celsius."""
    try:
        data = i2c.readfrom_mem(MLX90614_ADDR, MLX90614_TOBJ1, 3)
        raw = data[0] | (data[1] << 8)
        temp_k = raw * 0.02
        temp_c = temp_k - 273.15
        return round(temp_c, 2)
    except Exception:
        return 0.0


# ── MPU6050 Accelerometer/Gyroscope ──────────────────────────────────────────
MPU6050_ADDR = 0x68
MPU6050_PWR = 0x6B
MPU6050_ACCEL = 0x3B

_prev_accel_z = 9.81
_fall_cooldown = 0

def mpu6050_init():
    i2c.writeto_mem(MPU6050_ADDR, MPU6050_PWR, bytes([0]))  # Wake up

def mpu6050_read():
    """Returns (ax, ay, az, fall_detected)."""
    global _prev_accel_z, _fall_cooldown
    try:
        data = i2c.readfrom_mem(MPU6050_ADDR, MPU6050_ACCEL, 6)
        ax = (data[0] << 8 | data[1]) / 16384.0 * 9.81
        ay = (data[2] << 8 | data[3]) / 16384.0 * 9.81
        az = (data[4] << 8 | data[5]) / 16384.0 * 9.81

        # Fall detection: sudden z-axis change + total acceleration drop
        total_accel = math.sqrt(ax**2 + ay**2 + az**2)
        fall_detected = False

        if _fall_cooldown == 0:
            delta_z = abs(az - _prev_accel_z)
            # Impact phase: high acceleration
            if total_accel > 20:
                fall_detected = True
                _fall_cooldown = 10  # 10 reading cooldown
        else:
            _fall_cooldown -= 1

        _prev_accel_z = az
        return round(ax, 3), round(ay, 3), round(az, 3), fall_detected
    except Exception:
        return 0.0, 0.0, 9.81, False


# ── ECG Reading ───────────────────────────────────────────────────────────────
def read_ecg():
    """Returns ECG amplitude (0-1 normalized) and lead-off status."""
    if lo_minus.value() == 1 or lo_plus.value() == 1:
        return 0.0, True  # Leads off body
    raw = ecg_adc.read_u16()  # 0-65535
    normalized = raw / 65535.0
    return round(normalized, 4), False


# ── WiFi Connection ───────────────────────────────────────────────────────────
def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if not wlan.isconnected():
        print(f"Connecting to WiFi: {WIFI_SSID}")
        wlan.connect(WIFI_SSID, WIFI_PASS)
        timeout = 15
        while not wlan.isconnected() and timeout > 0:
            time.sleep(1)
            timeout -= 1
    if wlan.isconnected():
        print(f"✅ WiFi connected: {wlan.ifconfig()[0]}")
        return True
    print("❌ WiFi connection failed")
    return False


# ── MQTT Publisher ─────────────────────────────────────────────────────────────
def get_mqtt_client():
    try:
        from umqtt.robust import MQTTClient
        client = MQTTClient(DEVICE_ID, MQTT_BROKER, port=MQTT_PORT,
                            user=MQTT_USER, password=MQTT_PASS, keepalive=30)
        client.connect()
        return client
    except Exception as e:
        print(f"MQTT connect error: {e}")
        return None


# ── Main Loop ─────────────────────────────────────────────────────────────────
def main():
    print("🫀 VitalSync ESP32 Firmware Starting...")

    # Initialize sensors
    try:
        max30102_init()
        mpu6050_init()
        print("✅ Sensors initialized")
    except Exception as e:
        print(f"⚠️ Sensor init error: {e}")

    # Connect WiFi
    if not connect_wifi():
        print("Running in offline mode...")

    # Connect MQTT
    mqtt_client = get_mqtt_client()

    led = Pin(2, Pin.OUT)  # Built-in LED for status

    while True:
        try:
            # Read all sensors
            hr, spo2 = max30102_read()
            temp = mlx90614_read_temp()
            ax, ay, az, fall = mpu6050_read()
            ecg_val, leads_off = read_ecg()

            # Build payload
            payload = {
                "heart_rate": hr,
                "spo2": spo2,
                "temperature": temp,
                "ecg_value": ecg_val if not leads_off else 0,
                "motion_x": ax,
                "motion_y": ay,
                "motion_z": az,
                "fall_detected": fall,
                "leads_off": leads_off,
            }

            # Publish to MQTT
            if mqtt_client:
                try:
                    mqtt_client.publish(MQTT_TOPIC, json.dumps(payload), qos=1)
                    led.value(not led.value())  # Blink LED on each publish
                    print(f"📡 Published: HR={hr} SpO2={spo2}% Temp={temp}°C Fall={fall}")
                except Exception as e:
                    print(f"MQTT publish error: {e}")
                    # Try to reconnect
                    mqtt_client = get_mqtt_client()
            else:
                print(f"[LOCAL] HR={hr} SpO2={spo2}% Temp={temp}°C")

            # Emergency LED pattern
            if fall or spo2 < 90 or hr > 150:
                for _ in range(5):
                    led.value(1); time.sleep(0.1)
                    led.value(0); time.sleep(0.1)

        except Exception as e:
            print(f"Reading error: {e}")

        time.sleep(PUBLISH_INTERVAL)


if __name__ == "__main__":
    main()
